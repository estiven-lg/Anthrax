from Antrax_IDE import GUI

GUI()

