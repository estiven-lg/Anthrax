# Generated from antlr4_data/Antrax.g4 by ANTLR 4.7.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3%")
        buf.write("\u0108\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\3\2")
        buf.write("\3\2\3\2\3\2\6\2\65\n\2\r\2\16\2\66\3\2\3\2\5\2;\n\2\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\3\3\3\5\3[\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\3\4\3\4\3\4\5\4i\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3")
        buf.write("\5\3\5\3\5\3\6\6\6v\n\6\r\6\16\6w\3\7\6\7{\n\7\r\7\16")
        buf.write("\7|\3\b\6\b\u0080\n\b\r\b\16\b\u0081\3\t\6\t\u0085\n\t")
        buf.write("\r\t\16\t\u0086\3\n\3\n\3\n\3\n\3\n\3\n\6\n\u008f\n\n")
        buf.write("\r\n\16\n\u0090\3\n\3\n\3\13\3\13\3\13\3\13\3\13\3\13")
        buf.write("\3\13\3\13\3\13\3\13\6\13\u009f\n\13\r\13\16\13\u00a0")
        buf.write("\3\13\3\13\3\f\3\f\3\f\3\f\5\f\u00a9\n\f\3\f\3\f\3\r\3")
        buf.write("\r\3\r\3\r\3\r\3\16\3\16\3\16\3\16\3\17\3\17\3\17\3\17")
        buf.write("\3\17\5\17\u00bb\n\17\3\17\3\17\3\17\6\17\u00c0\n\17\r")
        buf.write("\17\16\17\u00c1\3\17\3\17\3\20\3\20\3\20\7\20\u00c9\n")
        buf.write("\20\f\20\16\20\u00cc\13\20\3\21\3\21\3\21\3\22\3\22\3")
        buf.write("\22\5\22\u00d4\n\22\3\23\3\23\3\23\3\23\3\23\7\23\u00db")
        buf.write("\n\23\f\23\16\23\u00de\13\23\5\23\u00e0\n\23\3\23\3\23")
        buf.write("\3\24\3\24\3\25\3\25\3\25\7\25\u00e9\n\25\f\25\16\25\u00ec")
        buf.write("\13\25\3\26\3\26\3\26\7\26\u00f1\n\26\f\26\16\26\u00f4")
        buf.write("\13\26\3\27\3\27\3\27\7\27\u00f9\n\27\f\27\16\27\u00fc")
        buf.write("\13\27\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\5\30\u0106")
        buf.write("\n\30\3\30\2\2\31\2\4\6\b\n\f\16\20\22\24\26\30\32\34")
        buf.write("\36 \"$&(*,.\2\5\3\2\36#\3\2\32\33\3\2\34\35\2\u0110\2")
        buf.write("\60\3\2\2\2\4Z\3\2\2\2\6\\\3\2\2\2\bj\3\2\2\2\nu\3\2\2")
        buf.write("\2\fz\3\2\2\2\16\177\3\2\2\2\20\u0084\3\2\2\2\22\u0088")
        buf.write("\3\2\2\2\24\u0094\3\2\2\2\26\u00a4\3\2\2\2\30\u00ac\3")
        buf.write("\2\2\2\32\u00b1\3\2\2\2\34\u00b5\3\2\2\2\36\u00c5\3\2")
        buf.write("\2\2 \u00cd\3\2\2\2\"\u00d0\3\2\2\2$\u00d5\3\2\2\2&\u00e3")
        buf.write("\3\2\2\2(\u00e5\3\2\2\2*\u00ed\3\2\2\2,\u00f5\3\2\2\2")
        buf.write(".\u0105\3\2\2\2\60\61\7\3\2\2\61\62\7\4\2\2\62\64\7\5")
        buf.write("\2\2\63\65\5\4\3\2\64\63\3\2\2\2\65\66\3\2\2\2\66\64\3")
        buf.write("\2\2\2\66\67\3\2\2\2\678\3\2\2\28:\7\6\2\29;\7\2\2\3:")
        buf.write("9\3\2\2\2:;\3\2\2\2;\3\3\2\2\2<=\5\30\r\2=>\7\7\2\2>[")
        buf.write("\3\2\2\2?@\5\32\16\2@A\7\7\2\2A[\3\2\2\2BC\5\6\4\2CD\7")
        buf.write("\7\2\2D[\3\2\2\2EF\5\22\n\2FG\7\7\2\2G[\3\2\2\2HI\5\24")
        buf.write("\13\2IJ\7\7\2\2J[\3\2\2\2KL\5\26\f\2LM\7\7\2\2M[\3\2\2")
        buf.write("\2NO\5\"\22\2OP\7\7\2\2P[\3\2\2\2QR\5\34\17\2RS\7\7\2")
        buf.write("\2S[\3\2\2\2TU\5$\23\2UV\7\7\2\2V[\3\2\2\2WX\5\b\5\2X")
        buf.write("Y\7\7\2\2Y[\3\2\2\2Z<\3\2\2\2Z?\3\2\2\2ZB\3\2\2\2ZE\3")
        buf.write("\2\2\2ZH\3\2\2\2ZK\3\2\2\2ZN\3\2\2\2ZQ\3\2\2\2ZT\3\2\2")
        buf.write("\2ZW\3\2\2\2[\5\3\2\2\2\\]\7\b\2\2]^\7\t\2\2^_\5&\24\2")
        buf.write("_`\7\n\2\2`a\7\5\2\2ab\5\16\b\2bh\7\6\2\2cd\7\13\2\2d")
        buf.write("e\7\5\2\2ef\5\20\t\2fg\7\6\2\2gi\3\2\2\2hc\3\2\2\2hi\3")
        buf.write("\2\2\2i\7\3\2\2\2jk\7\f\2\2kl\7\5\2\2lm\5\n\6\2mn\7\6")
        buf.write("\2\2no\7\r\2\2op\7\24\2\2pq\7\5\2\2qr\5\f\7\2rs\7\6\2")
        buf.write("\2s\t\3\2\2\2tv\5\4\3\2ut\3\2\2\2vw\3\2\2\2wu\3\2\2\2")
        buf.write("wx\3\2\2\2x\13\3\2\2\2y{\5\4\3\2zy\3\2\2\2{|\3\2\2\2|")
        buf.write("z\3\2\2\2|}\3\2\2\2}\r\3\2\2\2~\u0080\5\4\3\2\177~\3\2")
        buf.write("\2\2\u0080\u0081\3\2\2\2\u0081\177\3\2\2\2\u0081\u0082")
        buf.write("\3\2\2\2\u0082\17\3\2\2\2\u0083\u0085\5\4\3\2\u0084\u0083")
        buf.write("\3\2\2\2\u0085\u0086\3\2\2\2\u0086\u0084\3\2\2\2\u0086")
        buf.write("\u0087\3\2\2\2\u0087\21\3\2\2\2\u0088\u0089\7\16\2\2\u0089")
        buf.write("\u008a\7\t\2\2\u008a\u008b\5&\24\2\u008b\u008c\7\n\2\2")
        buf.write("\u008c\u008e\7\5\2\2\u008d\u008f\5\4\3\2\u008e\u008d\3")
        buf.write("\2\2\2\u008f\u0090\3\2\2\2\u0090\u008e\3\2\2\2\u0090\u0091")
        buf.write("\3\2\2\2\u0091\u0092\3\2\2\2\u0092\u0093\7\6\2\2\u0093")
        buf.write("\23\3\2\2\2\u0094\u0095\7\17\2\2\u0095\u0096\7\t\2\2\u0096")
        buf.write("\u0097\5\30\r\2\u0097\u0098\7\7\2\2\u0098\u0099\5&\24")
        buf.write("\2\u0099\u009a\7\7\2\2\u009a\u009b\5\32\16\2\u009b\u009c")
        buf.write("\7\n\2\2\u009c\u009e\7\5\2\2\u009d\u009f\5\4\3\2\u009e")
        buf.write("\u009d\3\2\2\2\u009f\u00a0\3\2\2\2\u00a0\u009e\3\2\2\2")
        buf.write("\u00a0\u00a1\3\2\2\2\u00a1\u00a2\3\2\2\2\u00a2\u00a3\7")
        buf.write("\6\2\2\u00a3\25\3\2\2\2\u00a4\u00a5\7\20\2\2\u00a5\u00a8")
        buf.write("\7\t\2\2\u00a6\u00a9\5&\24\2\u00a7\u00a9\7\27\2\2\u00a8")
        buf.write("\u00a6\3\2\2\2\u00a8\u00a7\3\2\2\2\u00a9\u00aa\3\2\2\2")
        buf.write("\u00aa\u00ab\7\n\2\2\u00ab\27\3\2\2\2\u00ac\u00ad\7\30")
        buf.write("\2\2\u00ad\u00ae\7\24\2\2\u00ae\u00af\7\21\2\2\u00af\u00b0")
        buf.write("\5&\24\2\u00b0\31\3\2\2\2\u00b1\u00b2\7\24\2\2\u00b2\u00b3")
        buf.write("\7\21\2\2\u00b3\u00b4\5&\24\2\u00b4\33\3\2\2\2\u00b5\u00b6")
        buf.write("\7\22\2\2\u00b6\u00b7\7\30\2\2\u00b7\u00b8\7\25\2\2\u00b8")
        buf.write("\u00ba\7\t\2\2\u00b9\u00bb\5\36\20\2\u00ba\u00b9\3\2\2")
        buf.write("\2\u00ba\u00bb\3\2\2\2\u00bb\u00bc\3\2\2\2\u00bc\u00bd")
        buf.write("\7\n\2\2\u00bd\u00bf\7\5\2\2\u00be\u00c0\5\4\3\2\u00bf")
        buf.write("\u00be\3\2\2\2\u00c0\u00c1\3\2\2\2\u00c1\u00bf\3\2\2\2")
        buf.write("\u00c1\u00c2\3\2\2\2\u00c2\u00c3\3\2\2\2\u00c3\u00c4\7")
        buf.write("\6\2\2\u00c4\35\3\2\2\2\u00c5\u00ca\5 \21\2\u00c6\u00c7")
        buf.write("\7\23\2\2\u00c7\u00c9\5 \21\2\u00c8\u00c6\3\2\2\2\u00c9")
        buf.write("\u00cc\3\2\2\2\u00ca\u00c8\3\2\2\2\u00ca\u00cb\3\2\2\2")
        buf.write("\u00cb\37\3\2\2\2\u00cc\u00ca\3\2\2\2\u00cd\u00ce\7\30")
        buf.write("\2\2\u00ce\u00cf\7\24\2\2\u00cf!\3\2\2\2\u00d0\u00d3\7")
        buf.write("\31\2\2\u00d1\u00d4\7\27\2\2\u00d2\u00d4\5&\24\2\u00d3")
        buf.write("\u00d1\3\2\2\2\u00d3\u00d2\3\2\2\2\u00d4#\3\2\2\2\u00d5")
        buf.write("\u00d6\7\25\2\2\u00d6\u00df\7\t\2\2\u00d7\u00dc\5&\24")
        buf.write("\2\u00d8\u00d9\7\23\2\2\u00d9\u00db\5&\24\2\u00da\u00d8")
        buf.write("\3\2\2\2\u00db\u00de\3\2\2\2\u00dc\u00da\3\2\2\2\u00dc")
        buf.write("\u00dd\3\2\2\2\u00dd\u00e0\3\2\2\2\u00de\u00dc\3\2\2\2")
        buf.write("\u00df\u00d7\3\2\2\2\u00df\u00e0\3\2\2\2\u00e0\u00e1\3")
        buf.write("\2\2\2\u00e1\u00e2\7\n\2\2\u00e2%\3\2\2\2\u00e3\u00e4")
        buf.write("\5(\25\2\u00e4\'\3\2\2\2\u00e5\u00ea\5*\26\2\u00e6\u00e7")
        buf.write("\t\2\2\2\u00e7\u00e9\5*\26\2\u00e8\u00e6\3\2\2\2\u00e9")
        buf.write("\u00ec\3\2\2\2\u00ea\u00e8\3\2\2\2\u00ea\u00eb\3\2\2\2")
        buf.write("\u00eb)\3\2\2\2\u00ec\u00ea\3\2\2\2\u00ed\u00f2\5,\27")
        buf.write("\2\u00ee\u00ef\t\3\2\2\u00ef\u00f1\5,\27\2\u00f0\u00ee")
        buf.write("\3\2\2\2\u00f1\u00f4\3\2\2\2\u00f2\u00f0\3\2\2\2\u00f2")
        buf.write("\u00f3\3\2\2\2\u00f3+\3\2\2\2\u00f4\u00f2\3\2\2\2\u00f5")
        buf.write("\u00fa\5.\30\2\u00f6\u00f7\t\4\2\2\u00f7\u00f9\5.\30\2")
        buf.write("\u00f8\u00f6\3\2\2\2\u00f9\u00fc\3\2\2\2\u00fa\u00f8\3")
        buf.write("\2\2\2\u00fa\u00fb\3\2\2\2\u00fb-\3\2\2\2\u00fc\u00fa")
        buf.write("\3\2\2\2\u00fd\u00fe\7\t\2\2\u00fe\u00ff\5&\24\2\u00ff")
        buf.write("\u0100\7\n\2\2\u0100\u0106\3\2\2\2\u0101\u0106\7\26\2")
        buf.write("\2\u0102\u0106\7\24\2\2\u0103\u0106\5$\23\2\u0104\u0106")
        buf.write("\7\27\2\2\u0105\u00fd\3\2\2\2\u0105\u0101\3\2\2\2\u0105")
        buf.write("\u0102\3\2\2\2\u0105\u0103\3\2\2\2\u0105\u0104\3\2\2\2")
        buf.write("\u0106/\3\2\2\2\27\66:Zhw|\u0081\u0086\u0090\u00a0\u00a8")
        buf.write("\u00ba\u00c1\u00ca\u00d3\u00dc\u00df\u00ea\u00f2\u00fa")
        buf.write("\u0105")
        return buf.getvalue()


class AntraxParser ( Parser ):

    grammarFileName = "Antrax.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'Program'", "'antrax'", "'{'", "'}'", 
                     "';'", "'if'", "'('", "')'", "'else'", "'try'", "'catch'", 
                     "'while'", "'for'", "'print'", "'='", "'Fx:'", "','", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "'return'", "'+'", "'-'", "'*'", "'/'", 
                     "'<'", "'>'", "'<='", "'>='", "'=='", "'!='" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "ID", "FID", "NUM", "STRING", 
                      "TYPE", "RETURN", "PLUS", "MINUS", "MULT", "DIV", 
                      "LT", "GT", "LEQ", "GEQ", "EQ", "NEQ", "WS", "COMMENT" ]

    RULE_root = 0
    RULE_stat = 1
    RULE_ifStat = 2
    RULE_tryStat = 3
    RULE_tryAction = 4
    RULE_catchAction = 5
    RULE_ifAction = 6
    RULE_elseAction = 7
    RULE_whileStat = 8
    RULE_forStat = 9
    RULE_printStat = 10
    RULE_varDecl = 11
    RULE_varAsg = 12
    RULE_funcStat = 13
    RULE_params = 14
    RULE_param = 15
    RULE_retStat = 16
    RULE_funcCall = 17
    RULE_expr = 18
    RULE_exprBool = 19
    RULE_exprAdd = 20
    RULE_exprMul = 21
    RULE_exprAtom = 22

    ruleNames =  [ "root", "stat", "ifStat", "tryStat", "tryAction", "catchAction", 
                   "ifAction", "elseAction", "whileStat", "forStat", "printStat", 
                   "varDecl", "varAsg", "funcStat", "params", "param", "retStat", 
                   "funcCall", "expr", "exprBool", "exprAdd", "exprMul", 
                   "exprAtom" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    ID=18
    FID=19
    NUM=20
    STRING=21
    TYPE=22
    RETURN=23
    PLUS=24
    MINUS=25
    MULT=26
    DIV=27
    LT=28
    GT=29
    LEQ=30
    GEQ=31
    EQ=32
    NEQ=33
    WS=34
    COMMENT=35

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class RootContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def EOF(self):
            return self.getToken(AntraxParser.EOF, 0)

        def getRuleIndex(self):
            return AntraxParser.RULE_root

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRoot" ):
                listener.enterRoot(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRoot" ):
                listener.exitRoot(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRoot" ):
                return visitor.visitRoot(self)
            else:
                return visitor.visitChildren(self)




    def root(self):

        localctx = AntraxParser.RootContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_root)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46
            self.match(AntraxParser.T__0)
            self.state = 47
            self.match(AntraxParser.T__1)
            self.state = 48
            self.match(AntraxParser.T__2)
            self.state = 50 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 49
                self.stat()
                self.state = 52 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

            self.state = 54
            self.match(AntraxParser.T__3)
            self.state = 56
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.state = 55
                self.match(AntraxParser.EOF)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varDecl(self):
            return self.getTypedRuleContext(AntraxParser.VarDeclContext,0)


        def varAsg(self):
            return self.getTypedRuleContext(AntraxParser.VarAsgContext,0)


        def ifStat(self):
            return self.getTypedRuleContext(AntraxParser.IfStatContext,0)


        def whileStat(self):
            return self.getTypedRuleContext(AntraxParser.WhileStatContext,0)


        def forStat(self):
            return self.getTypedRuleContext(AntraxParser.ForStatContext,0)


        def printStat(self):
            return self.getTypedRuleContext(AntraxParser.PrintStatContext,0)


        def retStat(self):
            return self.getTypedRuleContext(AntraxParser.RetStatContext,0)


        def funcStat(self):
            return self.getTypedRuleContext(AntraxParser.FuncStatContext,0)


        def funcCall(self):
            return self.getTypedRuleContext(AntraxParser.FuncCallContext,0)


        def tryStat(self):
            return self.getTypedRuleContext(AntraxParser.TryStatContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_stat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStat" ):
                listener.enterStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStat" ):
                listener.exitStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStat" ):
                return visitor.visitStat(self)
            else:
                return visitor.visitChildren(self)




    def stat(self):

        localctx = AntraxParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 88
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [AntraxParser.TYPE]:
                self.enterOuterAlt(localctx, 1)
                self.state = 58
                self.varDecl()
                self.state = 59
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.ID]:
                self.enterOuterAlt(localctx, 2)
                self.state = 61
                self.varAsg()
                self.state = 62
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__5]:
                self.enterOuterAlt(localctx, 3)
                self.state = 64
                self.ifStat()
                self.state = 65
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__11]:
                self.enterOuterAlt(localctx, 4)
                self.state = 67
                self.whileStat()
                self.state = 68
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__12]:
                self.enterOuterAlt(localctx, 5)
                self.state = 70
                self.forStat()
                self.state = 71
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__13]:
                self.enterOuterAlt(localctx, 6)
                self.state = 73
                self.printStat()
                self.state = 74
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.RETURN]:
                self.enterOuterAlt(localctx, 7)
                self.state = 76
                self.retStat()
                self.state = 77
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__15]:
                self.enterOuterAlt(localctx, 8)
                self.state = 79
                self.funcStat()
                self.state = 80
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.FID]:
                self.enterOuterAlt(localctx, 9)
                self.state = 82
                self.funcCall()
                self.state = 83
                self.match(AntraxParser.T__4)
                pass
            elif token in [AntraxParser.T__9]:
                self.enterOuterAlt(localctx, 10)
                self.state = 85
                self.tryStat()
                self.state = 86
                self.match(AntraxParser.T__4)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IfStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def ifAction(self):
            return self.getTypedRuleContext(AntraxParser.IfActionContext,0)


        def elseAction(self):
            return self.getTypedRuleContext(AntraxParser.ElseActionContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_ifStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStat" ):
                listener.enterIfStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStat" ):
                listener.exitIfStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStat" ):
                return visitor.visitIfStat(self)
            else:
                return visitor.visitChildren(self)




    def ifStat(self):

        localctx = AntraxParser.IfStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_ifStat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            self.match(AntraxParser.T__5)
            self.state = 91
            self.match(AntraxParser.T__6)
            self.state = 92
            self.expr()
            self.state = 93
            self.match(AntraxParser.T__7)
            self.state = 94
            self.match(AntraxParser.T__2)
            self.state = 95
            self.ifAction()
            self.state = 96
            self.match(AntraxParser.T__3)
            self.state = 102
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==AntraxParser.T__8:
                self.state = 97
                self.match(AntraxParser.T__8)
                self.state = 98
                self.match(AntraxParser.T__2)
                self.state = 99
                self.elseAction()
                self.state = 100
                self.match(AntraxParser.T__3)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TryStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tryAction(self):
            return self.getTypedRuleContext(AntraxParser.TryActionContext,0)


        def ID(self):
            return self.getToken(AntraxParser.ID, 0)

        def catchAction(self):
            return self.getTypedRuleContext(AntraxParser.CatchActionContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_tryStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTryStat" ):
                listener.enterTryStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTryStat" ):
                listener.exitTryStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTryStat" ):
                return visitor.visitTryStat(self)
            else:
                return visitor.visitChildren(self)




    def tryStat(self):

        localctx = AntraxParser.TryStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_tryStat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 104
            self.match(AntraxParser.T__9)
            self.state = 105
            self.match(AntraxParser.T__2)
            self.state = 106
            self.tryAction()
            self.state = 107
            self.match(AntraxParser.T__3)
            self.state = 108
            self.match(AntraxParser.T__10)
            self.state = 109
            self.match(AntraxParser.ID)
            self.state = 110
            self.match(AntraxParser.T__2)
            self.state = 111
            self.catchAction()
            self.state = 112
            self.match(AntraxParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class TryActionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_tryAction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTryAction" ):
                listener.enterTryAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTryAction" ):
                listener.exitTryAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTryAction" ):
                return visitor.visitTryAction(self)
            else:
                return visitor.visitChildren(self)




    def tryAction(self):

        localctx = AntraxParser.TryActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_tryAction)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 115 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 114
                self.stat()
                self.state = 117 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CatchActionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_catchAction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCatchAction" ):
                listener.enterCatchAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCatchAction" ):
                listener.exitCatchAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCatchAction" ):
                return visitor.visitCatchAction(self)
            else:
                return visitor.visitChildren(self)




    def catchAction(self):

        localctx = AntraxParser.CatchActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_catchAction)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 120 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 119
                self.stat()
                self.state = 122 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IfActionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_ifAction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfAction" ):
                listener.enterIfAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfAction" ):
                listener.exitIfAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfAction" ):
                return visitor.visitIfAction(self)
            else:
                return visitor.visitChildren(self)




    def ifAction(self):

        localctx = AntraxParser.IfActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_ifAction)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 125 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 124
                self.stat()
                self.state = 127 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ElseActionContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_elseAction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterElseAction" ):
                listener.enterElseAction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitElseAction" ):
                listener.exitElseAction(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitElseAction" ):
                return visitor.visitElseAction(self)
            else:
                return visitor.visitChildren(self)




    def elseAction(self):

        localctx = AntraxParser.ElseActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_elseAction)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 129
                self.stat()
                self.state = 132 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class WhileStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_whileStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStat" ):
                listener.enterWhileStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStat" ):
                listener.exitWhileStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStat" ):
                return visitor.visitWhileStat(self)
            else:
                return visitor.visitChildren(self)




    def whileStat(self):

        localctx = AntraxParser.WhileStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_whileStat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 134
            self.match(AntraxParser.T__11)
            self.state = 135
            self.match(AntraxParser.T__6)
            self.state = 136
            self.expr()
            self.state = 137
            self.match(AntraxParser.T__7)
            self.state = 138
            self.match(AntraxParser.T__2)
            self.state = 140 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 139
                self.stat()
                self.state = 142 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

            self.state = 144
            self.match(AntraxParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ForStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varDecl(self):
            return self.getTypedRuleContext(AntraxParser.VarDeclContext,0)


        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def varAsg(self):
            return self.getTypedRuleContext(AntraxParser.VarAsgContext,0)


        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_forStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterForStat" ):
                listener.enterForStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitForStat" ):
                listener.exitForStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitForStat" ):
                return visitor.visitForStat(self)
            else:
                return visitor.visitChildren(self)




    def forStat(self):

        localctx = AntraxParser.ForStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_forStat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 146
            self.match(AntraxParser.T__12)
            self.state = 147
            self.match(AntraxParser.T__6)
            self.state = 148
            self.varDecl()
            self.state = 149
            self.match(AntraxParser.T__4)
            self.state = 150
            self.expr()
            self.state = 151
            self.match(AntraxParser.T__4)
            self.state = 152
            self.varAsg()
            self.state = 153
            self.match(AntraxParser.T__7)
            self.state = 154
            self.match(AntraxParser.T__2)
            self.state = 156 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 155
                self.stat()
                self.state = 158 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

            self.state = 160
            self.match(AntraxParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class PrintStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def STRING(self):
            return self.getToken(AntraxParser.STRING, 0)

        def getRuleIndex(self):
            return AntraxParser.RULE_printStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrintStat" ):
                listener.enterPrintStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrintStat" ):
                listener.exitPrintStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrintStat" ):
                return visitor.visitPrintStat(self)
            else:
                return visitor.visitChildren(self)




    def printStat(self):

        localctx = AntraxParser.PrintStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_printStat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self.match(AntraxParser.T__13)
            self.state = 163
            self.match(AntraxParser.T__6)
            self.state = 166
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 164
                self.expr()
                pass

            elif la_ == 2:
                self.state = 165
                self.match(AntraxParser.STRING)
                pass


            self.state = 168
            self.match(AntraxParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarDeclContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(AntraxParser.TYPE, 0)

        def ID(self):
            return self.getToken(AntraxParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_varDecl

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarDecl" ):
                listener.enterVarDecl(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarDecl" ):
                listener.exitVarDecl(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarDecl" ):
                return visitor.visitVarDecl(self)
            else:
                return visitor.visitChildren(self)




    def varDecl(self):

        localctx = AntraxParser.VarDeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_varDecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.match(AntraxParser.TYPE)
            self.state = 171
            self.match(AntraxParser.ID)
            self.state = 172
            self.match(AntraxParser.T__14)
            self.state = 173
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class VarAsgContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(AntraxParser.ID, 0)

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_varAsg

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVarAsg" ):
                listener.enterVarAsg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVarAsg" ):
                listener.exitVarAsg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarAsg" ):
                return visitor.visitVarAsg(self)
            else:
                return visitor.visitChildren(self)




    def varAsg(self):

        localctx = AntraxParser.VarAsgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_varAsg)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 175
            self.match(AntraxParser.ID)
            self.state = 176
            self.match(AntraxParser.T__14)
            self.state = 177
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FuncStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(AntraxParser.TYPE, 0)

        def FID(self):
            return self.getToken(AntraxParser.FID, 0)

        def params(self):
            return self.getTypedRuleContext(AntraxParser.ParamsContext,0)


        def stat(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.StatContext)
            else:
                return self.getTypedRuleContext(AntraxParser.StatContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_funcStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncStat" ):
                listener.enterFuncStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncStat" ):
                listener.exitFuncStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncStat" ):
                return visitor.visitFuncStat(self)
            else:
                return visitor.visitChildren(self)




    def funcStat(self):

        localctx = AntraxParser.FuncStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_funcStat)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self.match(AntraxParser.T__15)
            self.state = 180
            self.match(AntraxParser.TYPE)
            self.state = 181
            self.match(AntraxParser.FID)
            self.state = 182
            self.match(AntraxParser.T__6)
            self.state = 184
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==AntraxParser.TYPE:
                self.state = 183
                self.params()


            self.state = 186
            self.match(AntraxParser.T__7)
            self.state = 187
            self.match(AntraxParser.T__2)
            self.state = 189 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 188
                self.stat()
                self.state = 191 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__5) | (1 << AntraxParser.T__9) | (1 << AntraxParser.T__11) | (1 << AntraxParser.T__12) | (1 << AntraxParser.T__13) | (1 << AntraxParser.T__15) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.TYPE) | (1 << AntraxParser.RETURN))) != 0)):
                    break

            self.state = 193
            self.match(AntraxParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParamsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.ParamContext)
            else:
                return self.getTypedRuleContext(AntraxParser.ParamContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParams" ):
                listener.enterParams(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParams" ):
                listener.exitParams(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParams" ):
                return visitor.visitParams(self)
            else:
                return visitor.visitChildren(self)




    def params(self):

        localctx = AntraxParser.ParamsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self.param()
            self.state = 200
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==AntraxParser.T__16:
                self.state = 196
                self.match(AntraxParser.T__16)
                self.state = 197
                self.param()
                self.state = 202
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ParamContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(AntraxParser.TYPE, 0)

        def ID(self):
            return self.getToken(AntraxParser.ID, 0)

        def getRuleIndex(self):
            return AntraxParser.RULE_param

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParam" ):
                listener.enterParam(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParam" ):
                listener.exitParam(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParam" ):
                return visitor.visitParam(self)
            else:
                return visitor.visitChildren(self)




    def param(self):

        localctx = AntraxParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_param)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 203
            self.match(AntraxParser.TYPE)
            self.state = 204
            self.match(AntraxParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RetStatContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(AntraxParser.RETURN, 0)

        def STRING(self):
            return self.getToken(AntraxParser.STRING, 0)

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_retStat

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRetStat" ):
                listener.enterRetStat(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRetStat" ):
                listener.exitRetStat(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRetStat" ):
                return visitor.visitRetStat(self)
            else:
                return visitor.visitChildren(self)




    def retStat(self):

        localctx = AntraxParser.RetStatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_retStat)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 206
            self.match(AntraxParser.RETURN)
            self.state = 209
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
            if la_ == 1:
                self.state = 207
                self.match(AntraxParser.STRING)
                pass

            elif la_ == 2:
                self.state = 208
                self.expr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FuncCallContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FID(self):
            return self.getToken(AntraxParser.FID, 0)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.ExprContext)
            else:
                return self.getTypedRuleContext(AntraxParser.ExprContext,i)


        def getRuleIndex(self):
            return AntraxParser.RULE_funcCall

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncCall" ):
                listener.enterFuncCall(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncCall" ):
                listener.exitFuncCall(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncCall" ):
                return visitor.visitFuncCall(self)
            else:
                return visitor.visitChildren(self)




    def funcCall(self):

        localctx = AntraxParser.FuncCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_funcCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 211
            self.match(AntraxParser.FID)
            self.state = 212
            self.match(AntraxParser.T__6)
            self.state = 221
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.T__6) | (1 << AntraxParser.ID) | (1 << AntraxParser.FID) | (1 << AntraxParser.NUM) | (1 << AntraxParser.STRING))) != 0):
                self.state = 213
                self.expr()
                self.state = 218
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==AntraxParser.T__16:
                    self.state = 214
                    self.match(AntraxParser.T__16)
                    self.state = 215
                    self.expr()
                    self.state = 220
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 223
            self.match(AntraxParser.T__7)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exprBool(self):
            return self.getTypedRuleContext(AntraxParser.ExprBoolContext,0)


        def getRuleIndex(self):
            return AntraxParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = AntraxParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.exprBool()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprBoolContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exprAdd(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.ExprAddContext)
            else:
                return self.getTypedRuleContext(AntraxParser.ExprAddContext,i)


        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.LT)
            else:
                return self.getToken(AntraxParser.LT, i)

        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.GT)
            else:
                return self.getToken(AntraxParser.GT, i)

        def LEQ(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.LEQ)
            else:
                return self.getToken(AntraxParser.LEQ, i)

        def GEQ(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.GEQ)
            else:
                return self.getToken(AntraxParser.GEQ, i)

        def EQ(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.EQ)
            else:
                return self.getToken(AntraxParser.EQ, i)

        def NEQ(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.NEQ)
            else:
                return self.getToken(AntraxParser.NEQ, i)

        def getRuleIndex(self):
            return AntraxParser.RULE_exprBool

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprBool" ):
                listener.enterExprBool(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprBool" ):
                listener.exitExprBool(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprBool" ):
                return visitor.visitExprBool(self)
            else:
                return visitor.visitChildren(self)




    def exprBool(self):

        localctx = AntraxParser.ExprBoolContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_exprBool)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 227
            self.exprAdd()
            self.state = 232
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.LT) | (1 << AntraxParser.GT) | (1 << AntraxParser.LEQ) | (1 << AntraxParser.GEQ) | (1 << AntraxParser.EQ) | (1 << AntraxParser.NEQ))) != 0):
                self.state = 228
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << AntraxParser.LT) | (1 << AntraxParser.GT) | (1 << AntraxParser.LEQ) | (1 << AntraxParser.GEQ) | (1 << AntraxParser.EQ) | (1 << AntraxParser.NEQ))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 229
                self.exprAdd()
                self.state = 234
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprAddContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exprMul(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.ExprMulContext)
            else:
                return self.getTypedRuleContext(AntraxParser.ExprMulContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.PLUS)
            else:
                return self.getToken(AntraxParser.PLUS, i)

        def MINUS(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.MINUS)
            else:
                return self.getToken(AntraxParser.MINUS, i)

        def getRuleIndex(self):
            return AntraxParser.RULE_exprAdd

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprAdd" ):
                listener.enterExprAdd(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprAdd" ):
                listener.exitExprAdd(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprAdd" ):
                return visitor.visitExprAdd(self)
            else:
                return visitor.visitChildren(self)




    def exprAdd(self):

        localctx = AntraxParser.ExprAddContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_exprAdd)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 235
            self.exprMul()
            self.state = 240
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==AntraxParser.PLUS or _la==AntraxParser.MINUS:
                self.state = 236
                _la = self._input.LA(1)
                if not(_la==AntraxParser.PLUS or _la==AntraxParser.MINUS):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 237
                self.exprMul()
                self.state = 242
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprMulContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exprAtom(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(AntraxParser.ExprAtomContext)
            else:
                return self.getTypedRuleContext(AntraxParser.ExprAtomContext,i)


        def MULT(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.MULT)
            else:
                return self.getToken(AntraxParser.MULT, i)

        def DIV(self, i:int=None):
            if i is None:
                return self.getTokens(AntraxParser.DIV)
            else:
                return self.getToken(AntraxParser.DIV, i)

        def getRuleIndex(self):
            return AntraxParser.RULE_exprMul

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprMul" ):
                listener.enterExprMul(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprMul" ):
                listener.exitExprMul(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprMul" ):
                return visitor.visitExprMul(self)
            else:
                return visitor.visitChildren(self)




    def exprMul(self):

        localctx = AntraxParser.ExprMulContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_exprMul)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 243
            self.exprAtom()
            self.state = 248
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==AntraxParser.MULT or _la==AntraxParser.DIV:
                self.state = 244
                _la = self._input.LA(1)
                if not(_la==AntraxParser.MULT or _la==AntraxParser.DIV):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 245
                self.exprAtom()
                self.state = 250
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprAtomContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(AntraxParser.ExprContext,0)


        def NUM(self):
            return self.getToken(AntraxParser.NUM, 0)

        def ID(self):
            return self.getToken(AntraxParser.ID, 0)

        def funcCall(self):
            return self.getTypedRuleContext(AntraxParser.FuncCallContext,0)


        def STRING(self):
            return self.getToken(AntraxParser.STRING, 0)

        def getRuleIndex(self):
            return AntraxParser.RULE_exprAtom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExprAtom" ):
                listener.enterExprAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExprAtom" ):
                listener.exitExprAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExprAtom" ):
                return visitor.visitExprAtom(self)
            else:
                return visitor.visitChildren(self)




    def exprAtom(self):

        localctx = AntraxParser.ExprAtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_exprAtom)
        try:
            self.state = 259
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [AntraxParser.T__6]:
                self.enterOuterAlt(localctx, 1)
                self.state = 251
                self.match(AntraxParser.T__6)
                self.state = 252
                self.expr()
                self.state = 253
                self.match(AntraxParser.T__7)
                pass
            elif token in [AntraxParser.NUM]:
                self.enterOuterAlt(localctx, 2)
                self.state = 255
                self.match(AntraxParser.NUM)
                pass
            elif token in [AntraxParser.ID]:
                self.enterOuterAlt(localctx, 3)
                self.state = 256
                self.match(AntraxParser.ID)
                pass
            elif token in [AntraxParser.FID]:
                self.enterOuterAlt(localctx, 4)
                self.state = 257
                self.funcCall()
                pass
            elif token in [AntraxParser.STRING]:
                self.enterOuterAlt(localctx, 5)
                self.state = 258
                self.match(AntraxParser.STRING)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





